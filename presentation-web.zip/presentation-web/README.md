https://dev.to/gridou/spring-boot-with-spotless-and-git-pre-commit-hooks-1h4f
https://medium.com/@nirav-shah/code-formatting-using-spotless-google-java-format-for-java-maven-projects-with-git-pre-commit-860d6c15bf7c


mvn initialize

https://github.com/google/styleguide