
package com.digiciel.app.service;

/**
 * @author jean-marie
 */

public interface PrescriptionService {

  void saidHello(String name);

}
