
package com.digiciel.app.service.impl;

import com.digiciel.app.service.PrescriptionService;

/**
 * dddd
 *
 * @author jean-marie
 */

public class PrescriptionServiceImpl implements PrescriptionService {
  private String nom;
  private String prenom;

  @Override
  public void saidHello(final String name) {

    // TODO Auto-generated method stub
    if (true) {
      System.err.println("ddd");

    } else {
      System.err.println("hoo");
    }

  }
}
