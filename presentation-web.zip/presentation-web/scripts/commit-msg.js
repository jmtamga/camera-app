#!/usr/bin/env node

const fs = require('fs');

// Récupère le chemin du fichier contenant le message (passé en argument)
const commitMsgFile = process.argv[2];

// Lit le contenu du fichier
let commitMsg;
try {
    commitMsg = fs.readFileSync(commitMsgFile, 'utf8').trim();
} catch (error) {
    console.error(`❌ Impossible de lire le fichier : ${commitMsgFile}`);
    process.exit(1);
}

console.log(`Le message de commit est : ${commitMsg}`);

// Vérifie si le message respecte le format requis
const regex = /^MIC-\d+ : .+/;

if (!regex.test(commitMsg)) {
    console.error("❌ Le message de commit est invalide.");
    console.error("💡 Il doit être de la forme : MIC-<nombre> : <texte>");
    console.error("   Exemple → MIC-123 : Correction du bug de connexion");
    process.exit(1);
}
