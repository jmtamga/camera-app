const { spawn } = require("child_process");
const { execSync } = require("child_process");
const path = require("path");
const fs = require("fs");

function runCommand(command, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(command, args, { stdio: "inherit", shell: true });

    proc.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`Échec de la commande: ${command} ${args.join(" ")}`));
      } else {
        resolve();
      }
    });
  });
}

function getModifiedFiles() {
  try {
    const output = execSync("git diff --cached --name-only", {
      encoding: "utf-8",
    });
    return output
      .split("\n")
      .filter(
        (file) =>
          (file.endsWith(".java") ||
            file.endsWith(".html") ||
            file.endsWith(".ts") ||
            file.endsWith(".less") ||
            file.endsWith(".js") ||
            file.endsWith(".css")) &&
          fs.existsSync(file)
      );
  } catch (err) {
    console.error("Échec de la récupération des fichiers modifiés:", err.message);
    return [];
  }
}

(async () => {
  try {
    const javaFiles = getModifiedFiles();

    if (javaFiles.length === 0) {
      console.log("✅ Aucun fichier à vérifier.");
      process.exit(0);
    }

    console.log("🔍 Exécution du contrôle Spotless en cours...");
    await runCommand("mvn", ["spotless:check"]);

    console.log("✅ Contrôle Spotless réussi.");
  } catch (err) {
    console.error(`❌ Échec du contrôle Spotless:\n${err.message}`);
    console.error('💡 Exécutez "mvn spotless:apply" pour corriger le formatage.');
    process.exit(1);
  }
})();
