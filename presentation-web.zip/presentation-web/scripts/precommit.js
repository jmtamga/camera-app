const { spawn } = require("child_process");
const { execSync } = require("child_process");
const path = require("path");
const fs = require("fs");

function runCommand(command, args) {
  return new Promise((resolve, reject) => {
    const proc = spawn(command, args, { stdio: "inherit", shell: true });

    proc.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`Command failed: ${command} ${args.join(" ")}`));
      } else {
        resolve();
      }
    });
  });
}

function getModifiedFiles() {
  try {
    const output = execSync("git diff --cached --name-only", {
      encoding: "utf-8",
    });
    return output
      .split("\n")
      .filter(
        (file) =>
          (file.endsWith(".java") ||
            file.endsWith(".html") ||
            file.endsWith(".ts") ||
            file.endsWith(".less") ||
            file.endsWith(".js") ||
            file.endsWith(".css")) &&
          fs.existsSync(file)
      );
  } catch (err) {
    console.error("Failed to get modified files:", err.message);
    return [];
  }
}

(async () => {
  try {
    const javaFiles = getModifiedFiles();

    if (javaFiles.length === 0) {
      console.log("✅ No files to check.");
      process.exit(0);
    }

    console.log("🔍 Running Spotless check...");
    await runCommand("mvn", ["spotless:check"]);

    console.log("✅ Spotless check passed.");
  } catch (err) {
    console.error(`❌ Spotless check failed:\n${err.message}`);
    console.error('💡 Run "mvn spotless:apply" to fix formatting.');
    process.exit(1);
  }
})();
