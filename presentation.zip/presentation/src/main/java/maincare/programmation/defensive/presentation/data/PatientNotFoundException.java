package maincare.programmation.defensive.presentation.data;

public class PatientNotFoundException extends Exception {
  private static final long serialVersionUID = 1L;

  public PatientNotFoundException(final String message) {
    super(message);
  }
}
