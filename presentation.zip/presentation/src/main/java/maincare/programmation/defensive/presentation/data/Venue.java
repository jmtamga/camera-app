package maincare.programmation.defensive.presentation.data;

import java.util.Date;
import java.util.Optional;

public class Venue {
  private Long venueId;
  private Date debut;
  private Date fin;

  private Patient patient;

  private InfoHebergement infoHebergement;

  public Venue(final Long venueId, final Date debut, final Date fin, final Patient patient) {
    super();
    this.venueId = venueId;
    this.debut = debut;
    this.fin = fin;
    this.patient = patient;
  }

  public Long getVenueId() {
    return venueId;
  }

  public void setVenueId(final Long venueId) {
    this.venueId = venueId;
  }

  public Date getDebut() {
    return debut;
  }

  public void setDebut(final Date debut) {
    this.debut = debut;
  }

  public Date getFin() {
    return fin;
  }

  public void setFin(final Date fin) {
    this.fin = fin;
  }

  public Patient getPatient() {
    return patient;
  }

  public void setPatient(final Patient patient) {
    this.patient = patient;
  }

  public Optional<Patient> getPatientOpt() {
    return Optional.ofNullable(patient);
  }

  public InfoHebergement getInfoHebergement() {
    return infoHebergement;
  }

  public void setInfoHebergement(final InfoHebergement infoHebergement) {
    this.infoHebergement = infoHebergement;
  }
}
