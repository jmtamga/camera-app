package maincare.programmation.defensive.presentation.data;

import java.util.ArrayList;
import java.util.List;

public class Prescription {

  private Long prescriptionId;

  private List<LignePrescription> lignes;

  private Venue venue;

  public Long getPrescriptionId() {
    return prescriptionId;
  }

  public void setPrescriptionId(final Long prescriptionId) {
    this.prescriptionId = prescriptionId;
  }

  public List<LignePrescription> getLignes() {
    if (lignes == null) {
      lignes = new ArrayList<>();
    }
    return lignes;
  }

  public void setLignes(final List<LignePrescription> lignes) {
    this.lignes = lignes;
  }

  public Venue getVenue() {
    return venue;
  }

  public void setVenue(final Venue venue) {
    this.venue = venue;
  }
}
