package maincare.programmation.defensive.presentation;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import maincare.programmation.defensive.presentation.data.InfoHebergement;
import maincare.programmation.defensive.presentation.data.Patient;
import maincare.programmation.defensive.presentation.data.PatientNotFoundException;
import maincare.programmation.defensive.presentation.data.Prescription;
import maincare.programmation.defensive.presentation.data.UniteFornctionnelle;
import maincare.programmation.defensive.presentation.data.Venue;
import maincare.programmation.defensive.presentation.data.VenueService;

public class App {

  private static final String CODE_PAR_DEFAUT = "CODE_DEFAULT";

  private static final Logger LOGGER = Logger.getLogger(App.class.getName());

  private static VenueService venueService = new VenueService();

  public static void main(final String[] args) throws PatientNotFoundException {
    LOGGER.info(getCodeUfRecommande());
    LOGGER.info(getCodeUf());

    List<Optional<String>> names = Arrays.asList(Optional.of("Alice"), Optional.of("Marie"));

    List<String> kst = names.stream().flatMap(Optional::stream).collect(Collectors.toList());

    LOGGER.info(getCodeUf());
  }

  private static String getCodeUfRecommande() throws PatientNotFoundException {
    Optional<Venue> optVenue = venueService.getVenueById(5L);

    return optVenue // Optional<Venue>
        .map(Venue::getInfoHebergement) // Optional<InfoHebergement>
        .map(InfoHebergement::getUf) // Optional<UniteFornctionnelle>
        .map(UniteFornctionnelle::getCode) // Optional<String>
        .orElse(CODE_PAR_DEFAUT);
  }

  private static String getCodeUf() {
    String codeUf = CODE_PAR_DEFAUT;
    Venue venue = venueService.getVenueByIdClassique(5L);
    if (venue != null
        && venue.getInfoHebergement() != null
        && venue.getInfoHebergement().getUf() != null) {
      UniteFornctionnelle uf = venue.getInfoHebergement().getUf();
      if (uf != null) {
        codeUf = uf.getCode();
      }
    }
    return codeUf;
  }

  private static String doCalcul() {
    LOGGER.info("Evaluation");
    return CODE_PAR_DEFAUT;
  }

  private static void traitementModerneOld() throws PatientNotFoundException {
    Prescription prescription = new Prescription();
    Optional<Venue> optVenue = venueService.getVenueById(5L);

    Patient pat =
        optVenue
            .map(Venue::getPatient)
            .orElseThrow(() -> new PatientNotFoundException("Aucun patient trouvé"));

    System.err.println(pat.getNom());

    pat =
        optVenue
            .flatMap(Venue::getPatientOpt)
            .orElseThrow(() -> new PatientNotFoundException("Aucun patient trouvé"));
    System.err.println(pat.getNom());

    Optional<UniteFornctionnelle> ufOpt =
        optVenue.map(Venue::getInfoHebergement).map(InfoHebergement::getUf);
    //  .flatMap(InfoHebergement::getUf);

    Optional<String> codeOpt =
        optVenue
            .map(Venue::getInfoHebergement)
            .map(InfoHebergement::getUf)
            .map(UniteFornctionnelle::getCode);

    String code =
        optVenue
            .map(Venue::getInfoHebergement)
            .map(InfoHebergement::getUf)
            .map(UniteFornctionnelle::getCode)
            .orElse(CODE_PAR_DEFAUT);

    System.err.println(code);

    Venue v = null;
    Patient p = null;
    System.err.println(Objects.equals(v, p));
  }
}
