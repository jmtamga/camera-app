package maincare.programmation.defensive.presentation.data;

public class LignePrescription {

  private final Long id;
  private final String libelle;
  private final String posologie;

  public LignePrescription(final Long id, final String libelle, final String posologie) {
    super();
    this.id = id;
    this.libelle = libelle;
    this.posologie = posologie;
  }

  public Long getId() {
    return id;
  }

  public String getLibelle() {
    return libelle;
  }

  public String getPosologie() {
    return posologie;
  }
}
