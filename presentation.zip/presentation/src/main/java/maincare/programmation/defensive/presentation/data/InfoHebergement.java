package maincare.programmation.defensive.presentation.data;

public class InfoHebergement {
  private UniteFornctionnelle uf;

  public UniteFornctionnelle getUf() {
    return uf;
  }

  public void setUf(final UniteFornctionnelle uf) {
    this.uf = uf;
  }
}
