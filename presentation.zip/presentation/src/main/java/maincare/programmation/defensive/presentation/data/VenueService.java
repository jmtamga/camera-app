package maincare.programmation.defensive.presentation.data;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class VenueService {
  private final Map<Long, Venue> venues;

  public VenueService() {
    venues = new HashMap<>();
    for (int i = 1; i < 13; i++) {
      Long id = Long.valueOf(i);
      String nom = "NOM " + i;
      String prenom = "PRENOM " + i;
      venues.put(id, new Venue(id, new Date(), null, new Patient(id, nom, prenom)));
    }
  }

  public Optional<Venue> getVenueById(final Long venueId) {
    Objects.requireNonNull(venueId, "L'id de la venue est nulle");
    return Optional.ofNullable(venues.get(venueId));
  }

  public Venue getVenueByIdClassique(final Long venueId) {
    Objects.requireNonNull(venueId, "L'id de la venue est nulle");
    return venues.get(venueId);
  }
}
