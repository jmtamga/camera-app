package maincare.programmation.defensive.presentation.data;

public class Patient {
  private final Long patientId;
  private final String nom;
  private final String prenom;

  public Patient(final Long patientId, final String nom, final String prenom) {
    super();
    this.patientId = patientId;
    this.nom = nom;
    this.prenom = prenom;
  }

  public Long getPatientId() {
    return patientId;
  }

  public String getNom() {
    return nom;
  }

  public String getPrenom() {
    return prenom;
  }
}
